###
### Script to install BANF Solution
###
$script:solutionName = 'banf.wsp'
$script:featureBDCModel = 'BANF_BDCModel'
$script:featureSolution = 'BANF_Solution'
$script:featureContacts = 'BANF_Contacts'
$WSPPath = ''
$webUrl = ''
$script:listBANF = 'BANFList'
$script:listDocs = 'PurchasingDocuments'
$script:wpGallery = 'Web Part Gallery'
$script:wpName = 'BANFContacts.webpart'
###


###
Start-SPAssignment -Global
###


###
function WaitForTimerJob([string]$solutionName) {
$solution = Get-SPSolution -Identity $solutionName -ErrorAction SilentlyContinue
if ($solution -ne $null) {
 while ($solution.JobExists) {
  $jobStatus = $solution.JobStatus
  Start-Sleep -Seconds 2
  if ($jobStatus -eq [Microsoft.SharePoint.Administration.SPRunningJobStatus]::Succeeded) {
   return $true
  }
 } 
}
}
###


###
function UninstallSolution() {
if ($script:WSPPath -eq ''){
 $script:WSPPath = Read-Host "Please enter the solution package location (example: c:\temp\banf.wsp)"
}
if ($webUrl -eq '') {
 $script:webUrl = Read-Host "Please enter the URL of the SharePoint site where you want to install the solution (example: http://myServer/purchasing)"
 $script:web = Get-SPWeb $webUrl
 $script:site = $web.site
 $script:webApp = $site.WebApplication
}

# Retract features and solution if present
$feature=Get-SPFeature -Identity $featureBDCModel -ErrorAction:SilentlyContinue
 if ($feature -ne $null) {
 Write-Host "Retracting feature" $featureBDCModel"..."
 Disable-SPFeature -Identity $featureBDCModel -Confirm:$false
 Uninstall-SPFeature -Identity $featureBDCModel -Force -Confirm:$false
 }
$feature=Get-SPFeature -Identity $featureSolution -Web $web.Url -ErrorAction:SilentlyContinue
 if ($feature -ne $null) {
 Write-Host "Retracting feature" $featureSolution"..."
 Disable-SPFeature -Identity $featureSolution -Url $web.Url -Confirm:$false
 Uninstall-SPFeature -Identity $featureSolution -Force -Confirm:$false
 }
$feature=Get-SPFeature -Identity $featureContacts -Site $site.Url -ErrorAction:SilentlyContinue
 if ($feature -ne $null) {
 Write-Host "Retracting feature" $featureContacts"..."
 Disable-SPFeature -Identity $featureContacts -Url $site.Url -Confirm:$false
 Uninstall-SPFeature -Identity $featureContacts -Force -Confirm:$false
 }
$solution=Get-SPSolution -Identity $solutionName -ErrorAction:SilentlyContinue
 if ($solution -ne $null) {
  if ($solution.Deployed) { 
   Uninstall-SPSolution -Identity $solutionName -WebApplication $webApp -Confirm:$false
   WaitForTimerJob $solutionName
  }
 Write-Host "Retracting solution" $solutionName"..."
 Remove-SPSolution -Identity $solutionName -Confirm:$false
 }
# Removing BANFList
$list=$web.lists[$listBANF]
if ($list -ne $null) {
 $list.Delete()
 Write-Host $listBANF "deleted."
}
# Removing PurchasingDocuments
$list=$web.lists[$listDocs]
if ($list -ne $null) {
 $list.Delete()
 Write-Host $listDocs "deleted."
}
# Removing BANF.aspx page
$file = $web.GetFile($web.Url+"/BANF/BANF.aspx")
if ($file -ne $null) {
 $file.Delete()
 Write-Host $file "deleted."
}
# Removing Contacts Web Part
$rootweb = Get-SPWeb $site.Url
$list=$rootweb.Lists[$wpGallery]
if ($list -ne $null) {
 $item=$list.items | where {$_.Name -match $wpName}
 if ($item -ne $null) {
  $item.Delete()
  Write-Host $wpName "deleted."
 }
}
}
###


###
function InstallSolution() {
UninstallSolution
if ($script:WSPPath -eq ''){
 $script:WSPPath = Read-Host "Please enter the solution package location (example: c:\temp\banf.wsp)"
}
if ($script:webUrl -eq '') {
 $script:webUrl = Read-Host "Please enter the URL of the SharePoint site where you want to install the solution (example: http://myServer/purchasing)"
 $script:web = Get-SPWeb $webUrl
 $script:site = $web.site
 $script:webApp = $site.WebApplication
}

Write-Host "Installing Solution..."$solutionName
Add-SPSolution -LiteralPath $WSPPath
Install-SPSolution -Identity $solutionName -WebApplication $webApp -GACDeployment -Confirm:$false
Write-Host "Solution is being deployed..."
WaitForTimerJob $solutionName
Get-SPSolution -Identity $solutionName
Write-Host "Activating Features..."
Enable-SPFeature $featureSolution -Url $web.Url -Verbose:$false
Enable-SPFeature $featureContacts -Url $site.Url -Verbose:$false
Write-Host "Installation completed."
}
###


###
InstallSolution
Stop-SPAssignment -Global
###